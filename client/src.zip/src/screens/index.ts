export { default as HomeScreen } from './bottomTab/Home/HomeScreen';
export { default as OrderScreen } from './bottomTab/Order/OrderScreen';
export { default as ProductScreen } from './bottomTab/Product/ProductScreen';
export { default as StatisticalScreen } from './bottomTab/Statistical/StatisticalScreen';
export { default as MenuScreen } from './bottomTab/Menu/MenuScreen';
export { default as SplashScreen } from './main/Splash/SplashScreen';
export { default as LoginScreen } from './main/Login/LoginScreen';


