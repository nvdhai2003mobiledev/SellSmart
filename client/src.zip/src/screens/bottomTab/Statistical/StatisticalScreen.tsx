import {Text, View} from 'react-native';
import React from 'react';

const StatisticalScreen = () => {
  return (
    <View>
      <Text>StatisticalScreen</Text>
    </View>
  );
};
export default StatisticalScreen;
