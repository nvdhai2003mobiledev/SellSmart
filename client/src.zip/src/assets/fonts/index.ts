export enum Fonts {
  Inter_Regular = "Inter_18pt-Regular",
  Inter_SemiBold = "Inter_18pt-SemiBold",
  Inter_Bold = "Inter_18pt-Bold",
}
