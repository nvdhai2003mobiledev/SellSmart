export enum Images {
  LOGO = require('./logo.png'),

  LOGO2 = require('./logo.jpg'),
  LOGO3 = require('./logo3.png'),
  ForgotPass =require('./Devices.png'),
  Dienthoai =require('./DeviceMobile.png'),
 Key =require('./LockKey.png'),
Logo4= require('./logo4.png'),
Logo5= require('./logo5.png'),

  AVATA=require('./Avatar ByeWind.png'),
  SHOP=require('./shop.png')

}