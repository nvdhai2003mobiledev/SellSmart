export const color = {
  primaryColor: '#007AFF',
  accentColor: {
    darkColor: '#363D4E',
    whiteColor: '#FFFFFF',
    blackColor: '#000000',
    errorColor: '#FF3B30',
    grayColor: '#747475',
    closeColor: '#A1AEDB'
  },
  backgroundColor: '#F9F9FF',
  inputColor: '#F6F7F9',
  
};